import javafx.scene.layout.BorderPane;

public class MainPage extends BorderPane{
    
}
