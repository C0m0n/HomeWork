public class Constants {
    //Constants
    public static final String ACCOUNT_DIR = "accounts/" ;
    public static final String EAGLE_BANK = "EagleBank.txt";
    
}
