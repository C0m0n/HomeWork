David Greni (2526610)
11 Sep 2023
This program is a binary search that finds the index of a number in a given array.
No known bugs
Refernces: Algorithms 4th Edition by Robert Sedgewick and Kevin Wayne 