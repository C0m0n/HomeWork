To run this program simply compile and run TestSort.java his will run both of the sorting algorithems and will output the results to the cli. 

Commands

javac TestSort.java
java TestSort