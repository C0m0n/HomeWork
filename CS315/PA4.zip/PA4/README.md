Written By: David Greni
Date: 2022-12-02 
This program reads in text from the input.txt file. Then takes all words and puts them into a BST. Then it prints out the words in alphabetical order and the number of times each word appears in the text file. Then those items are taken from the BST and placed into a max heap and printed out in order of most frequent to least frequent. 
